getwd()
setwd("C:\\Users\\User\\Desktop\\IT24102218")

## (01)
# (i)
# Binomial distribution with n = 50 and p = 0.85

# (ii)
1 - pbinom(46,50,0.85,lower.tail = TRUE)

## (02)
# (i)
# No of calls come in during one hour

# (ii)
# Poisson distribution with an average of 12 calls per hour

# (iii)
dpois(15,12)

