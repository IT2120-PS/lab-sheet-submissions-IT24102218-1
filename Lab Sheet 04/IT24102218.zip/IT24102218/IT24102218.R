getwd()
setwd("C:/Users/it24102218/Desktop/IT24102218")

##  (01)
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

## (02)
str(branch_data)

## (03)
boxplot(branch_data$Sales_X1,main = "Boxplot for sales", outline = TRUE, horizontal = TRUE)

## (04)
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

## (05)
find_outliers <- function(x) { 
  Q1 <- quantile(x)[0.25]
  Q3 <- quantile(x)[0.75]
  IQR  <- Q3 - Q1
  
  Upper_bound <- Q3 + 1.5 * IQR
  Lower_bound <- Q1 - 1.5 * IQR
  
  outliers <- x[x < Lower_bound | x > Upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years_X3)